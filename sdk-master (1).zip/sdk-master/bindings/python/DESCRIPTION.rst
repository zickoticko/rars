Mega SDK Python Bindings
========================

This package contains the Python bindings to the Mega SDK for interfacing the
Mega cloud storage platform.

Please see ``README.md`` for further information on how to build and install
the Python bindings package.
